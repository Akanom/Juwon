import { Row, Col, Container } from 'reactstrap';

const About = () => {
    return (
        <Container fluid className='main-container'>
            <Row>
                <Col className='text-center'>This is the About page</Col>
            </Row>
        </Container>
    );
};

export default About;
