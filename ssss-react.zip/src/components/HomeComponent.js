import { Row, Col, Container } from 'reactstrap';

const Home = () => {
    return (
        <Container fluid className='main-container'>
            <Row>
                <Col className='text-center'>
                    This is a deployment demonstration of a simple React site using
                    react-router.
                </Col>
            </Row>
        </Container>
    );
};

export default Home;
